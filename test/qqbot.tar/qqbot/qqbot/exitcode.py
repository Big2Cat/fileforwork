# -*- coding: utf-8 -*-

QSESSION_ERROR = 201
RESTART = 202
