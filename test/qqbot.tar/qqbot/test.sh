source ~/Py3Venv/qqbot-venv/bin/activate
pip uninstall qqbot
pip install .

popup bash test-bot.sh

qqbot -u eva
